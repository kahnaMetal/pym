<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Clientes_model extends CI_Model
{
	public function construct(){
		parent::__construct();
	}	

	public function consultarPersona($id){
		$this->db->select('
			documentCustomer,
			nameCustomer,
			lastnameCustomer,
			phoneCustomer,
			cellphoneCustomer,
			emailCustomer,
			addressCustomer,
			cityCustomer_fkCities
		');
		$this->db->where('statusCustomer', '1');
		$this->db->where('documentCustomer', $id);
		return $this->db->get('customers');
	}

	public function consultarEmpresa($id){
		$this->db->select('
			nitCustomer,
			businessDigitCustomer,
			businessNameCustomer,
			phoneCustomer,
			cellphoneCustomer,
			emailCustomer,
			addressCustomer,
			cityCustomer_fkCities
		');
		$this->db->where('statusCustomer', '1');
		$this->db->where('nitCustomer', $id);
		return $this->db->get('customers');
	}

	public function registrar($d){
		$this->db->trans_begin();
		$this->db->insert('customers',$d);
		if($this->db->trans_status() === FALSE){//SI HUBO ERROR REGISTRANDO EN LA BASE DE DATOS
			$this->db->trans_rollback();//REVERSAR CAMBIOS
			return array(
				'status' => 'danger',
				'message' => 'Error registrando cliente en la base de datos'
			);
		} else {//SI EL REGISTRO FUE SATISFACTORIO
			$this->db->trans_commit();
			return array(
				'status' => 'success',
				'message' => 'Cliente registrado satisfactoriamente'
			);
		}
	}

}
